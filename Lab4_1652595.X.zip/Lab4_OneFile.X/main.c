/*
 * File:   main.c
 * Author: ngqui
 *
 * Created on October 7, 2019, 12:28 PM
 */
#ifdef _18F8722
#pragma config  OSC = HSPLL
#pragma config 	FCMEN = OFF
#pragma config 	IESO = OFF
#pragma config 	PWRT = OFF
#pragma config 	BOREN = OFF
#pragma config 	WDT = OFF
#pragma config 	MCLRE = ON
#pragma config 	LVP = OFF
#pragma config 	XINST = OFF
#endif
//**************************************

#include <xc.h>
#include <stdbool.h>
#include <stdint.h>
#include "LL.h"



typedef unsigned long int timestamp_t;
typedef void timer_callback_t;
//typedef unsigned long int uint64_t;


#define INTERNAL_CLOCK 8000000
#define MAX_CALLBACK 10


long long int timer_counter;
int timer_var = 10;
int task_counter = 0;


void set_timer();
void TMR1_Start(void);
void TMR1_Stop(void);

int start_timer(int timer_vaddr);
timestamp_t get_time(void);
uint32_t register_timer(uint64_t delay, timer_callback_t (* callback)(), void *data ); 
int remove_timer(uint32_t id);
int stop_timer(void);
int timer_ISR();    

void update();

void __interrupt() process(void);

void OSCILLATOR(void) ;
void PIN_MANAGER(void) ;
void INTERRUPT() ;
void ADC(void) ;
void TMR1_IN(void) ;

void SYSTEM_IN() ;
void STRUC_IN();
void increaseLED(){
    LATD++;
}
void setLED(){
    LATD = 0xFF;
}
void setLED2(){
    LATD = 0x00;
}
void main(void) {
    SYSTEM_IN();
    INTCONbits.GIE = 1;
    INTCONbits.PEIE = 1;
    register_timer(100, increaseLED, NULL);
    register_timer(1000, setLED, NULL);
    register_timer(600, setLED2, NULL);
    //remove_timer(1);
    while (1){
        
    }
    return;
}

void OSCILLATOR(void) {
    OSCCON = 0x76; //Set internal clock = 8MHz/4 
    OSCTUNE = 0x00;
}

void PIN_MANAGER(void) {
    TRISD = 0x00;
    LATD = 0x00;
}

void INTERRUPT() {
    RCONbits.IPEN = 0;
    IPR1bits.TMR1IP = 0;
}

void ADC(void) {
    ADCON1 = 0x0F;
}

void TMR1_IN(void) {
    T1CON = 0x7D; //Set pre-scale = 8, enable internal clock = 2MHz / 8 = 250kHz
    /*
     Normally, Timer1 count from 0 to FFFF,
     * Assume that we need a clock of x (s), then we need f = x.internal_clock cycles before interrupt
     * So {TMR1H:TMR1L} = FFFF - f
     * 
     */
    set_timer();
    PIR1bits.TMR1IF = 0;
    PIE1bits.TMR1IE = 1;
    TMR1_Start();
}

void STRUCT_IN(){
    
    for  (int idx = 0; idx < MAXNUM + 1; idx++){
        headList[idx].address = idx;
        headList[idx].link_address = MAXNUM ;
        headList[idx].used = 0;
        headList[idx].flag = 0;
        
    }
}
void SYSTEM_IN() {
    OSCILLATOR();
    PIN_MANAGER();
    ADC();
    INTERRUPT();
    TMR1_IN();
    STRUCT_IN();
}

void set_timer(){
    unsigned long int frequency = INTERNAL_CLOCK/32;
    int step = 1000/timer_var;
    int unit = frequency/step;
    TMR1L = 0xFFFF - unit;
   // LATD = frequency;
    TMR1H = (0xFFFF - unit) >> 8;
    
}
void TMR1_Start(void) {
    T1CONbits.TMR1ON = 1;
}

void TMR1_Stop(void) {
    T1CONbits.TMR1ON = 0;
}

int start_timer(int timer_vaddr){
    timer_var = timer_vaddr;
    timer_counter = 0;
}
timestamp_t get_time(void){
    return timer_counter*timer_var;
}
int stop_timer(void){
    TMR1_Stop();
}

int timer_ISR(){
    set_timer();
    PIR1bits.TMR1IF = 0 ;
    timer_counter++;
    if (index > 0){
        headList[head_index].counter--;
        if (headList[head_index].counter <= 0){
            headList[head_index].callback_function();
            update();
        }
    }
    
}

void update(){
    int tmp = head_index;
    head_index = headList[head_index].link_address;
    freeTask(tmp);
    insertTask(headList[tmp].id, headList[tmp].time, headList[tmp].callback_function);
    
}

uint32_t register_timer(uint64_t delay, timer_callback_t (* callback)(), void *data ){
    insertTask(task_counter, delay, callback);
    task_counter++;
}

int remove_timer(uint32_t id){
    deleteTask(id);
    
}

void __interrupt() process(void) {
    if (PIE1bits.TMR1IE == 1 && PIR1bits.TMR1IF == 1) {
        timer_ISR();
        //set_timer();
    } else {

    }
}