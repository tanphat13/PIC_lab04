/*
 * File:   LL.c
 * Author: ngqui
 *
 * Created on October 18, 2019, 11:17 AM
 */


#include "LL.h"
void setVal(int idx, int new_id, int new_counter, int new_time, void(* callback)() ){
        headList[idx].id = new_id;
        headList[idx].counter = new_counter;
        headList[idx].scounter = new_counter;
        headList[idx].time = new_time;
        headList[idx].callback_function = callback;
        headList[idx].flag = 0;
        headList[idx].used = 1;
        
}
void insertTask(int id, int time, void(* callback)()) {
    //find position for new element
    int prev = MAXNUM;
	unsigned int cur = head_index;
	unsigned int next;
    int sum = 0;
    int prev_sum = 0;
    int parameter;
    enum position{BEGIN, MIDDLE, END};
    enum position pos = BEGIN;
    int idx;
    while (cur != MAXNUM && index > 0){
        next = headList[cur].link_address;
        sum = sum + headList[cur].scounter;
        //TODO
        pos = END;
        idx = cur;
        parameter = time;
        if (sum >= time){
            if (cur == head_index){
                pos = BEGIN;
                idx = head_index;
                parameter = time;
            }
            else{
                    pos = MIDDLE;
                    idx = prev;
                    parameter = time - prev_sum;
            }
            break;
        }
        prev_sum = sum;
        prev = cur;
        cur = next;
    }
//Add new element into the list
    int tmp;
    int new;
    switch(pos){
        case BEGIN:
            tmp = head_index;
            //create new task
            new = hash(index);
            setVal(new, id, time, time, callback);
            //insert new task at the begin of the list;
            head_index = new;
            if (index == 0) headList[new].link_address = MAXNUM;
            else {
                headList[new].link_address = tmp;
                updateList(tmp, parameter);//update list 
            }
            index++;
            break;
        case MIDDLE:
            tmp = headList[prev].link_address;
            //create new task
            new = hash(index);
            setVal(new, id, parameter, time, callback);
            //insert new task at the middle of the list;
            headList[prev].link_address = new;
            headList[new].link_address = tmp;
            updateList(cur, parameter);//update list
            index++;
            break;
        case END:
            //create new task
            new = hash(index);
            setVal(new, id, time - sum, time, callback);
            headList[idx].link_address = new;
            index++;
            break;
        default:
            break;
    }
}
void updateList(unsigned int index, int coeff){
    unsigned int run = index;
    if (run != MAXNUM){
        
        headList[run].scounter = headList[run].scounter - coeff;
        headList[run].counter = headList[run].counter - coeff;
    }
}



void freeTask(int idx){
	headList[idx].link_address = MAXNUM;
    headList[idx].used = 0;
}

void deleteTask(int id){
	if (index == 0) return;
	int prev = MAXNUM;
	unsigned int cur = head_index;
	unsigned int next;
	while (cur != MAXNUM){
		next = headList[cur].link_address;
		//TODO
		if (headList[cur].id == id){
			if (prev == MAXNUM){
				head_index = headList[cur].link_address;
				updateList(head_index, -headList[cur].scounter);
				freeTask(cur);
			}	
			else{
				headList[prev].link_address = headList[cur].link_address;
				updateList(next, -headList[cur].scounter);
				freeTask(cur);
			}	 
			index--;
		}
		prev = cur;
		cur = next;
	}
}
int hash(int val){
    int result = val%MAXNUM;
    while (headList[result].used == 1){
        result++;
    }
    return result;
}

