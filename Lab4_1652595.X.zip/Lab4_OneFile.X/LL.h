#ifndef LL_H
#define LL_H
#include <xc.h>
#include <stdbool.h>
#include <stdint.h>
#define MAXNUM 100
int index = 0;
int head_index = 0;
struct task {
    int address;
    int link_address;
    unsigned char used;
    int id;
    void (*callback_function)(void);
    int time;
    int counter;
    int scounter;
    unsigned char flag;
};

struct task headList[MAXNUM + 1];
void setVal(int idx, int new_id, int new_counter, int new_time, void(* callback)() );
void insertTask(int id, int time, void(* callback)()) ;
void updateList(unsigned int index, int coeff);
void freeTask(int idx);
void deleteTask(int id);
int hash(int val);
#endif